---
name: Kevin Marcelo-Castillo
semester: Fall 2023
course: CIS 106 Linux Fundamentals
---

![pfp](pexels-bruno-salvadori2-2269872.jpg)

# Kevin Marcelo-Castillo

**Technical Support**

**Executive Summary**

Knowledgeable about technology and how to troubleshoot common problems. Able to solve problems quickly and efficiently. 

<hr>

## Experience 

### TechEarth Inc.
***Technical Support Supervisor- Dec, 2018 - Nov, 2019***
Drived employee engagement and development, managed case escalations

### Eliteness Co.
***Technical Support Specialist- Dec, 2016 - Oct, 2017***
Provided technical assistance in evaluating software installation, tested and evaluated equipment to meet company standards.

<hr>

## Education

### Passaic County Community College
***Associate's Degree- Technical Support - Sep, 2014- Dec, 2016***

### International High School
***High School Diploma- Jun, 2014***

<hr>

## Projects

### ITgame
***Primary Developer- Jun, 2018-Present***
An educational game that makes IT concepts easy to understand. 

<hr>

## Skills

### Microsoft Suite
I have working knowledge of Microsoft Word, Excel, PowerPoint, and Access
### Python
I have used Python for data entry and automation.

<hr>

## Recognition

### Most Likely To Succeed
***International High School- Jun,2014*** 
Voted Most Likely To Succeed by peers.

<hr>

## Associations

### American Red Cross
***Volunteer- Jun, 2015- Sep, 2015***
Attended fundraising events and donated blood to patients.