---
name: Kevin Marcelo-Castillo
semester: Fall 2023
course: CIS 106 Linux Fundamentals
---

![pfp](pexels-bruno-salvadori2-2269872.jpg)

# Kevin Marcelo-Castillo

**Technical Support**

**Executive Summary**

Knowledgeable about technology and how to troubleshoot common problems. Able to solve problems quickly and efficiently. 

<hr>

## Experience 

### TechEarth Inc.
***Technical Support Supervisor- Oct, 2023 - Present***
Drived employee engagement and development, managed case escalations

### Eliteness Co.
***Technical Support Specialist- Dec, 2022 - Oct, 2023***
Provided technical assistance in evaluating software installation, tested and evaluated equipment to meet company standards.

<hr>

## Education

### Passaic County Community College
***Associate's Degree- Technical Support - Dec, 2022- Present***

### International High School
***High School Diploma- Jun, 2022***

<hr>

## Projects

### ITgame
***Primary Developer- Jun, 2018-Present***
An educational game that makes IT concepts easy to understand. 

<hr>

## Skills

### Microsoft Suite
I have working knowledge of Microsoft Word, Excel, PowerPoint, and Access
### Python
I have used Python for data entry and automation.

<hr>

## Recognition

### Most Likely To Succeed
***International High School- Jun, 2022*** 
Voted Most Likely To Succeed by peers.

<hr>

## Associations

### American Red Cross
***Volunteer- Aug, 2022- Sep, 2022***
Attended fundraising events and donated blood to patients.